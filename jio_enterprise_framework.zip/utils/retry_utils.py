
import time

class RetryUtils:

    @staticmethod
    def retry_until(condition_function, retry_action=None, interval=30):
        while True:
            if condition_function():
                return True

            if retry_action:
                retry_action()

            time.sleep(interval)
