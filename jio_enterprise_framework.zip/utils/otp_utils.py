
from utils.logger import get_logger

logger = get_logger(__name__)

class OTPUtils:

    @staticmethod
    def handle_invalid_otp(popup_text):
        expected = "Oops Authentication failed. 3 OTP verification pending"
        return expected.lower() in popup_text.lower()
