
import allure
from core.base_test import BaseTest
from pages.homepage.navigation_page import NavigationPage

@allure.feature("Homepage Navigation")
class TestHomepageNavigation(BaseTest):

    def test_homepage_navigation(self):
        navigation = NavigationPage(self.driver)

        navigation.verify_homepage_loaded()

        modules = [
            "jio_router",
            "plus_icon",
            "bell_icon",
            "guest_wifi",
            "stb_remote",
            "reboot",
            "block_access",
            "parental_control",
            "smart_devices",
            "network",
            "more"
        ]

        for module in modules:
            navigation.open_module_and_return(module)
