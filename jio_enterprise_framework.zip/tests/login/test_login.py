
import allure
from core.base_test import BaseTest
from pages.login.login_page import LoginPage
from config.config import TEST_MOBILE_NUMBER

@allure.feature("Login")
class TestLogin(BaseTest):

    def test_login_flow(self):
        login = LoginPage(self.driver)
        login.login_with_mobile(TEST_MOBILE_NUMBER)
        login.wait_for_manual_otp_and_submit()
