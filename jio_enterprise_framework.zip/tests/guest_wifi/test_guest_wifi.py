
import pytest

@pytest.mark.skip(reason="Future scalable module")
def test_placeholder():
    pass
