
from appium.webdriver.common.appiumby import AppiumBy

class LoginLocators:
    MOBILE_INPUT = (AppiumBy.ID, "com.jio.myjiohome:id/etMobile")
    GET_OTP_BUTTON = (AppiumBy.ID, "com.jio.myjiohome:id/btnGetOtp")
    SUBMIT_BUTTON = (AppiumBy.ID, "com.jio.myjiohome:id/btnSubmit")
    RESEND_OTP_BUTTON = (AppiumBy.ID, "com.jio.myjiohome:id/btnResendOtp")
    INVALID_OTP_POPUP = (AppiumBy.ID, "com.jio.myjiohome:id/tvMessage")
    OK_BUTTON = (AppiumBy.ID, "android:id/button1")
