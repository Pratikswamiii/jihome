
from appium.webdriver.common.appiumby import AppiumBy

class NavigationLocators:
    HOME_BANNER = (AppiumBy.ID, "com.jio.myjiohome:id/homeBanner")

    MODULES = {
        "jio_router": (AppiumBy.ACCESSIBILITY_ID, "Jio Router"),
        "plus_icon": (AppiumBy.ACCESSIBILITY_ID, "Add"),
        "bell_icon": (AppiumBy.ACCESSIBILITY_ID, "Bell"),
        "guest_wifi": (AppiumBy.ACCESSIBILITY_ID, "Guest Wifi"),
        "stb_remote": (AppiumBy.ACCESSIBILITY_ID, "STB Remote"),
        "reboot": (AppiumBy.ACCESSIBILITY_ID, "Reboot"),
        "block_access": (AppiumBy.ACCESSIBILITY_ID, "Block Access"),
        "parental_control": (AppiumBy.ACCESSIBILITY_ID, "Parental Control"),
        "smart_devices": (AppiumBy.ACCESSIBILITY_ID, "Smart Devices"),
        "network": (AppiumBy.ACCESSIBILITY_ID, "Network"),
        "more": (AppiumBy.ACCESSIBILITY_ID, "More")
    }
