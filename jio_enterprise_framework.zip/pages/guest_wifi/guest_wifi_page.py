
from core.base_page import BasePage

class GuestWifiPage(BasePage):

    def open_feature(self):
        pass
