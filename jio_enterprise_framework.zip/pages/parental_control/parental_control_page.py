
from core.base_page import BasePage

class ParentalControlPage(BasePage):

    def open_feature(self):
        pass
