
import time
from core.base_page import BasePage
from locators.login.login_locators import LoginLocators
from utils.retry_utils import RetryUtils
from utils.logger import get_logger
from utils.otp_utils import OTPUtils

logger = get_logger(__name__)

class LoginPage(BasePage):

    def login_with_mobile(self, mobile_number):
        logger.info("Entering mobile number")
        self.enter_text(LoginLocators.MOBILE_INPUT, mobile_number)

        if not self.is_enabled(LoginLocators.GET_OTP_BUTTON):
            raise AssertionError("Get OTP button is disabled")

        self.click(LoginLocators.GET_OTP_BUTTON)
        logger.info("Clicked Get OTP")

    def wait_for_manual_otp_and_submit(self):

        def condition():
            try:
                if self.is_enabled(LoginLocators.SUBMIT_BUTTON):
                    self.click(LoginLocators.SUBMIT_BUTTON)
                    logger.info("Submit button enabled and clicked")
                    return True

                if self.is_visible(LoginLocators.INVALID_OTP_POPUP):
                    popup = self.wait_for_element(LoginLocators.INVALID_OTP_POPUP).text
                    logger.warning(f"Invalid OTP popup detected: {popup}")

                    if OTPUtils.handle_invalid_otp(popup):
                        self.click(LoginLocators.OK_BUTTON)

                return False
            except Exception:
                return False

        def retry():
            logger.info("Waiting 30 seconds before resend OTP")
            time.sleep(30)

            if self.is_visible(LoginLocators.RESEND_OTP_BUTTON):
                self.click(LoginLocators.RESEND_OTP_BUTTON)
                logger.info("Clicked resend OTP")

        RetryUtils.retry_until(condition, retry)
