
from core.base_page import BasePage

class NetworkPage(BasePage):

    def open_feature(self):
        pass
