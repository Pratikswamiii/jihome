
from core.base_page import BasePage
from locators.homepage.navigation_locators import NavigationLocators
from utils.logger import get_logger

logger = get_logger(__name__)

class NavigationPage(BasePage):

    def verify_homepage_loaded(self):
        assert self.is_visible(NavigationLocators.HOME_BANNER), "Homepage not loaded"

    def open_module_and_return(self, module_name):
        locator = NavigationLocators.MODULES[module_name]

        logger.info(f"Opening module: {module_name}")
        self.click(locator)

        logger.info(f"Module opened: {module_name}")
        self.navigate_back()

        self.verify_homepage_loaded()
        logger.info(f"Returned to homepage from: {module_name}")
