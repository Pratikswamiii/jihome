
import pytest
from core.driver_factory import DriverFactory

class BaseTest:

    @pytest.fixture(autouse=True)
    def setup(self):
        self.driver = DriverFactory.create_driver()
        yield
        self.driver.quit()
