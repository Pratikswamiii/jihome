
from appium import webdriver
from appium.options.android import UiAutomator2Options
from config.config import *

class DriverFactory:

    @staticmethod
    def create_driver():
        options = UiAutomator2Options()
        options.platform_name = PLATFORM_NAME
        options.automation_name = AUTOMATION_NAME
        options.device_name = DEVICE_NAME
        options.app_package = APP_PACKAGE
        options.app_activity = APP_ACTIVITY
        options.no_reset = True
        options.new_command_timeout = 300
        return webdriver.Remote("http://127.0.0.1:4723", options=options)
