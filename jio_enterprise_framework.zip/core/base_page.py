
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from appium.webdriver.common.appiumby import AppiumBy

class BasePage:

    def __init__(self, driver):
        self.driver = driver

    def wait_for_element(self, locator, timeout=20):
        return WebDriverWait(self.driver, timeout).until(
            EC.visibility_of_element_located(locator)
        )

    def wait_for_clickable(self, locator, timeout=20):
        return WebDriverWait(self.driver, timeout).until(
            EC.element_to_be_clickable(locator)
        )

    def click(self, locator):
        self.wait_for_clickable(locator).click()

    def enter_text(self, locator, text):
        element = self.wait_for_element(locator)
        element.clear()
        element.send_keys(text)

    def safe_send_keys(self, locator, text):
        self.enter_text(locator, text)

    def is_visible(self, locator):
        try:
            return self.wait_for_element(locator).is_displayed()
        except:
            return False

    def is_enabled(self, locator):
        try:
            return self.wait_for_element(locator).is_enabled()
        except:
            return False

    def navigate_back(self):
        self.driver.back()

    def retry_click(self, locator, retries=3):
        for _ in range(retries):
            try:
                self.click(locator)
                return
            except:
                pass
        raise Exception(f"Unable to click: {locator}")

    def swipe(self):
        pass

    def scroll(self):
        pass
