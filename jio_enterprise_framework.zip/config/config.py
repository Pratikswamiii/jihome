
APP_PACKAGE = "com.jio.myjiohome"
APP_ACTIVITY = "com.jio.myjiohome.splash.SplashActivity"

PLATFORM_NAME = "Android"
AUTOMATION_NAME = "UiAutomator2"
DEVICE_NAME = "Android Device"

DEFAULT_TIMEOUT = 20
POLL_INTERVAL = 30

TEST_MOBILE_NUMBER = "8104913714"
