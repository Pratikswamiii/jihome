import allure

from pages.home_page import HomePage
from utils.logger import logger


@allure.feature("Login")
@allure.story("Valid Login")
@allure.title("Verify login with valid mobile number")
def test_login(driver):

    logger.info("Starting JioHome login flow")

    home_page = HomePage(driver)

    home_page.login()