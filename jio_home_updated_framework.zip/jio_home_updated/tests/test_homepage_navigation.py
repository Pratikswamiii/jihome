import allure

from pages.home_navigation_page import HomeNavigationPage
from pages.home_page import HomePage


@allure.feature("Home Navigation")
@allure.title("Validate home page modules")
def test_homepage_navigation(driver):

    home_page = HomePage(driver)
    navigation_page = HomeNavigationPage(driver)

    home_page.login()

    modules = [
        "Jio Router",
        "Plus",
        "Notifications",
        "Guest Wifi",
        "STB Remote",
        "Reboot",
        "Block Access",
        "Parental Control",
        "Smart Devices",
        "Network",
        "More"
    ]

    for module in modules:
        navigation_page.navigate_and_validate(module)