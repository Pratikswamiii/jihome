import time
import allure

from pages.base_page import BasePage
from locators.home_locators import HomeLocators
from utils.logger import logger


class HomePage(BasePage):

    def login(self, mobile_number="8104913714"):

        self.enter_mobile_number(mobile_number)
        self.validate_and_click_get_otp()
        self.wait_for_otp_and_submit()
        self.verify_login_success()

    def enter_mobile_number(self, mobile_number):

        with allure.step("Enter mobile number"):

            self.enter_text(
                HomeLocators.MOBILE_INPUT,
                mobile_number
            )

            logger.info(f"Mobile number entered: {mobile_number}")

    def validate_and_click_get_otp(self):

        with allure.step("Validate Get OTP button state"):

            if not self.is_enabled(HomeLocators.GET_OTP_BUTTON):
                logger.error("Get OTP button is disabled")
                raise AssertionError("Get OTP button is disabled")

            logger.info("Get OTP button enabled")

            self.click(HomeLocators.GET_OTP_BUTTON)

            logger.info("Get OTP button clicked")

    def wait_for_otp_and_submit(self, resend_interval=30):

        with allure.step("Wait for manual OTP and submit"):

            logger.info("Waiting for user to enter OTP manually")

            while True:

                cycle_start = time.time()

                while (time.time() - cycle_start) < resend_interval:

                    self.handle_invalid_otp_popup()

                    if self.is_enabled(HomeLocators.SUBMIT_BUTTON):

                        logger.info("Submit button enabled")

                        self.click(HomeLocators.SUBMIT_BUTTON)

                        logger.info("Submit button clicked")

                        return

                    time.sleep(2)

                logger.info("30 seconds completed. Triggering resend OTP")

                if self.is_visible(HomeLocators.RESEND_OTP_BUTTON):

                    self.click(HomeLocators.RESEND_OTP_BUTTON)

                    logger.info("Resend OTP button clicked")

    def handle_invalid_otp_popup(self):

        if self.is_visible(HomeLocators.AUTH_FAILED_POPUP):

            popup_text = self.get_text(
                HomeLocators.AUTH_FAILED_POPUP
            )

            logger.warning(f"Invalid OTP popup detected: {popup_text}")

            assert "Authentication failed" in popup_text

            self.click(
                HomeLocators.AUTH_FAILED_OK_BUTTON
            )

            logger.info("Authentication failed popup dismissed")

    def verify_login_success(self):

        assert self.is_visible(
            HomeLocators.HOME_SCREEN_IDENTIFIER
        ), "Home page did not load after login"

        logger.info("Login successful")