import allure

from pages.base_page import BasePage
from locators.home_navigation_locators import HomeNavigationLocators
from locators.home_locators import HomeLocators
from utils.logger import logger


class HomeNavigationPage(BasePage):

    def navigate_and_validate(self, module_name):

        locator = HomeNavigationLocators.MODULES[module_name]

        with allure.step(f"Open {module_name}"):

            self.click(locator)

            logger.info(f"{module_name} opened successfully")

        with allure.step(f"Navigate back from {module_name}"):

            self.driver.back()

            assert self.is_visible(
                HomeLocators.HOME_SCREEN_IDENTIFIER
            ), f"Home screen not visible after returning from {module_name}"

            logger.info(f"Returned successfully from {module_name}")