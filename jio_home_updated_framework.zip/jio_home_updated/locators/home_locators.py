from appium.webdriver.common.appiumby import AppiumBy


class HomeLocators:

    MOBILE_INPUT = (
        AppiumBy.CLASS_NAME,
        "android.widget.EditText"
    )

    GET_OTP_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Get OTP"
    )

    SUBMIT_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Submit"
    )

    RESEND_OTP_BUTTON = (
        AppiumBy.XPATH,
        "//*[contains(@content-desc,'Resend') or contains(@text,'Resend')]"
    )

    AUTH_FAILED_POPUP = (
        AppiumBy.XPATH,
        "//*[contains(@text,'Authentication failed')]"
    )

    AUTH_FAILED_OK_BUTTON = (
        AppiumBy.XPATH,
        "//*[@text='OK' or @content-desc='OK']"
    )

    HOME_SCREEN_IDENTIFIER = (
        AppiumBy.XPATH,
        "//*[contains(@text,'Guest Wifi') or contains(@content-desc,'Guest Wifi')]"
    )