from appium.webdriver.common.appiumby import AppiumBy


class HomeNavigationLocators:

    MODULES = {
        "Jio Router": (AppiumBy.XPATH, "//*[contains(@text,'Jio Router')]"),
        "Plus": (AppiumBy.XPATH, "//*[contains(@content-desc,'Plus') or contains(@text,'+')]"),
        "Notifications": (AppiumBy.XPATH, "//*[contains(@content-desc,'Bell') or contains(@text,'Notification')]"),
        "Guest Wifi": (AppiumBy.XPATH, "//*[contains(@text,'Guest Wifi')]"),
        "STB Remote": (AppiumBy.XPATH, "//*[contains(@text,'STB Remote')]"),
        "Reboot": (AppiumBy.XPATH, "//*[contains(@text,'Reboot')]"),
        "Block Access": (AppiumBy.XPATH, "//*[contains(@text,'Block Access')]"),
        "Parental Control": (AppiumBy.XPATH, "//*[contains(@text,'Parental')]"),
        "Smart Devices": (AppiumBy.XPATH, "//*[contains(@text,'Smart Devices')]"),
        "Network": (AppiumBy.XPATH, "//*[contains(@text,'Network')]"),
        "More": (AppiumBy.XPATH, "//*[contains(@text,'More')]")
    }