APP_PACKAGE = "com.jio.home"
APP_ACTIVITY = "com.jio.home.cleanarchitecture.common.screen.JioHomeLaunchActivity"
APPIUM_SERVER = "http://127.0.0.1:4723"