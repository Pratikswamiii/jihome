from appium import webdriver
from appium.options.android import UiAutomator2Options

from utils.config import (
    APP_PACKAGE,
    APP_ACTIVITY,
    APPIUM_SERVER
)


class DriverFactory:

    @staticmethod
    def get_driver():

        options = UiAutomator2Options()

        options.platform_name = "Android"
        options.device_name = "Android"
        options.automation_name = "UiAutomator2"

        options.app_package = APP_PACKAGE
        options.app_activity = APP_ACTIVITY

        options.no_reset = True
        options.auto_grant_permissions = True
        options.dont_stop_app_on_reset = True

        driver = webdriver.Remote(
            APPIUM_SERVER,
            options=options
        )

        driver.implicitly_wait(3)

        return driver