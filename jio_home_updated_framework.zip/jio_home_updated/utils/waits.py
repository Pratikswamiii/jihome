from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException


class WaitUtils:

    @staticmethod
    def wait_for_presence(driver, locator, timeout=20):
        return WebDriverWait(driver, timeout).until(
            EC.presence_of_element_located(locator)
        )

    @staticmethod
    def wait_for_visible(driver, locator, timeout=20):
        return WebDriverWait(driver, timeout).until(
            EC.visibility_of_element_located(locator)
        )

    @staticmethod
    def wait_for_clickable(driver, locator, timeout=20):
        return WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable(locator)
        )

    @staticmethod
    def wait_until(driver, condition_function, timeout=30, poll_frequency=2):
        return WebDriverWait(
            driver,
            timeout,
            poll_frequency=poll_frequency
        ).until(condition_function)

    @staticmethod
    def is_element_visible(driver, locator, timeout=5):
        try:
            WaitUtils.wait_for_visible(driver, locator, timeout)
            return True
        except TimeoutException:
            return False