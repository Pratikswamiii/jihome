from appium.webdriver.common.appiumby import AppiumBy


class DeviceLocators:

    SEARCH_APPS = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textContains("Search")'
    )

    SEARCH_INPUT = (
        AppiumBy.CLASS_NAME,
        "android.widget.EditText"
    )

    JIOHOME_APP_ICON = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().text("JioHome").clickable(true)'
    )

    PLAY_STORE_ICON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Play Store"
    )