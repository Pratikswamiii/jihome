from appium.webdriver.common.appiumby import AppiumBy


class PlayStoreLocators:

    SEARCH_BAR = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().descriptionContains("Search")'
    )

    SEARCH_INPUT = (
        AppiumBy.CLASS_NAME,
        "android.widget.EditText"
    )

    JIOHOME_RESULT = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textContains("JioHome")'
    )

    INSTALL_BUTTON = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textMatches("Install|Update|Open")'
    )