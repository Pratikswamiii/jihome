import allure

from pages.home_page import HomePage


@allure.feature("Login")
@allure.story("Valid Login")
@allure.title("Verify login with valid mobile number")
@allure.description(
    "User enters valid mobile number, "
    "receives OTP, enters OTP manually "
    "and logs into Jio Home app successfully"
)
def test_login(driver):

    home_page = HomePage(driver)

    home_page.login()