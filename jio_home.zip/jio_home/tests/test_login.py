import allure

from pages.device_page import DevicePage
from pages.home_page import HomePage
from pages.playstore_page import PlayStorePage
from utils.logger import logger


@allure.feature("Login")
@allure.story("Valid Login")
@allure.title("Verify login with valid mobile number")
def test_login(driver):

    device_page = DevicePage(driver)
    playstore_page = PlayStorePage(driver)
    home_page = HomePage(driver)

    logger.info("Starting JioHome application discovery flow")

    # Step 1 → Go to Android Home Screen
    device_page.go_to_home_screen()

    # Step 2 → Open Galaxy Finder / App Drawer Search
    device_page.open_app_search()

    # Step 3 → Search JioHome App
    device_page.search_jiohome_app()

    # Step 4 → Verify app available or not
    if device_page.is_jiohome_visible():

        logger.info("JioHome app found on device")

        # Step 5 → Open app
        device_page.open_jiohome_from_launcher()

    else:

        logger.info("JioHome app not found. Opening Play Store")

        # Step 6 → Open Play Store
        device_page.open_play_store()

        # Step 7 → Search JioHome in Play Store
        playstore_page.search_jiohome()

        # Step 8 → Install/Open app
        playstore_page.install_or_open_jiohome()

    # Step 9 → Continue login flow
    home_page.login()