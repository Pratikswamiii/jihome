import allure
from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from locators.playstore_locators import PlayStoreLocators
from utils.logger import logger


class PlayStorePage(BasePage):

    def search_jiohome(self, app_name="JioHome"):

        with allure.step(f"Search {app_name} in Play Store"):
            logger.info("Waiting for Play Store to load")

            search_box = self.wait_for_element(
                (
                    AppiumBy.CLASS_NAME,
                    "android.widget.EditText"
                ),
                timeout=20
            )

            logger.info("Clicking Play Store search box")

            search_box.click()

            logger.info(f"Searching app: {app_name}")

            search_box.clear()
            search_box.send_keys(app_name)

            self.driver.press_keycode(66)

            logger.info("Search submitted successfully")


    def install_or_open_jiohome(self):
        with allure.step("Install or Open JioHome app"):
            if self.is_visible(PlayStoreLocators.OPEN_BUTTON, timeout=10):
                logger.info("JioHome already installed. Opening app")
                self.click(PlayStoreLocators.OPEN_BUTTON)
                return

            if self.is_visible(PlayStoreLocators.INSTALL_BUTTON, timeout=10):
                logger.info("Installing JioHome app")
                self.click(PlayStoreLocators.INSTALL_BUTTON)

            self.wait_for_element(PlayStoreLocators.OPEN_BUTTON, timeout=180)
            self.click(PlayStoreLocators.OPEN_BUTTON)
            logger.info("JioHome app installed and opened successfully")
