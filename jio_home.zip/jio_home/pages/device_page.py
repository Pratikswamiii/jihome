import allure
from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from locators.device_locators import DeviceLocators
from utils.logger import logger


class DevicePage(BasePage):

    def go_to_home_screen(self):
        with allure.step("Go to device home screen"):
            logger.info("Navigating to Android home screen")
            self.driver.press_keycode(3)

    def open_app_search(self):

        with allure.step("Open Galaxy Finder search"):

            logger.info("Opening Samsung app drawer")

            size = self.driver.get_window_size()

            start_x = size["width"] // 2
            start_y = int(size["height"] * 0.85)

            end_x = start_x
            end_y = int(size["height"] * 0.25)

            self.driver.swipe(
                start_x,
                start_y,
                end_x,
                end_y,
                800
            )

            logger.info("Searching for Galaxy Finder search box")

            if self.is_visible(DeviceLocators.SEARCH_APPS, timeout=10):
                self.click(DeviceLocators.SEARCH_APPS)

    def search_jiohome_app(self):

        with allure.step("Search JioHome app"):

            logger.info("Searching JioHome app from launcher")

            search_box = self.wait_for_element(
                DeviceLocators.SEARCH_INPUT,
                timeout=10
            )

            search_box.clear()
            search_box.send_keys("JioHome")

    def is_jiohome_visible(self):

        with allure.step("Verify JioHome app installed on device"):

            logger.info("Checking installed packages for JioHome")

            try:

                result = self.driver.execute_script(
                    "mobile: shell",
                    {
                        "command": "pm",
                        "args": ["list", "packages", "com.jio.home"]
                    }
                )

                output = result.get("stdout", "").strip()

                logger.info(f"ADB package output: {output}")

                if "com.jio.home" in output:
                    logger.info("JioHome application is installed")

                    return True

                logger.info("JioHome application is NOT installed")

                return False

            except Exception as e:

                logger.error(f"Failed to verify installed package: {e}")

                return False

    def open_jiohome_from_launcher(self):

        with allure.step("Open JioHome from launcher"):

            self.click(DeviceLocators.JIOHOME_APP_ICON)

            logger.info("JioHome app launched")

    def open_play_store(self):

        with allure.step("Open Play Store"):

            self.driver.press_keycode(3)

            if self.is_visible(DeviceLocators.PLAY_STORE_ICON, timeout=5):
                self.click(DeviceLocators.PLAY_STORE_ICON)

            logger.info("Play Store opened")