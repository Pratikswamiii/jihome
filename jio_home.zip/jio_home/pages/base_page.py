from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from utils.logger import logger


class BasePage:

    def __init__(self, driver):
        self.driver = driver

    def wait_for_element(self, locator, timeout=30):

        logger.info(f"Waiting for element: {locator}")

        try:
            return WebDriverWait(
                self.driver,
                timeout
            ).until(
                EC.presence_of_element_located(locator)
            )

        except TimeoutException:

            logger.error(f"Element not found: {locator}")
            raise

    def enter_text(self, locator, text):

        logger.info(f"Entering text: {text}")

        element = self.wait_for_element(locator)

        element.clear()
        element.send_keys(text)

    def click(self, locator):

        logger.info(f"Clicking element: {locator}")

        element = self.wait_for_element(locator)

        element.click()

    def is_visible(self, locator, timeout=5):

        try:

            WebDriverWait(
                self.driver,
                timeout
            ).until(
                EC.visibility_of_element_located(locator)
            )

            return True

        except:
            return False

    def is_enabled(self, locator, timeout=5):

        try:

            element = WebDriverWait(
                self.driver,
                timeout
            ).until(
                EC.presence_of_element_located(locator)
            )

            return element.is_enabled()

        except:
            return False

    def scroll_down(self):

        logger.info("Scrolling down")

        size = self.driver.get_window_size()

        start_x = size["width"] / 2

        start_y = size["height"] * 0.8

        end_y = size["height"] * 0.3

        self.driver.swipe(
            start_x,
            start_y,
            start_x,
            end_y,
            1000
        )

        logger.info("Scroll completed")