
from appium.webdriver.common.appiumby import AppiumBy


class HomeNavigationLocators:

    JIO_ROUTER = (
        AppiumBy.ACCESSIBILITY_ID,
        "Jio Router"
    )

    PLUS_ICON = (
        AppiumBy.XPATH,
        '//android.view.View[@content-desc="Add Device icon"]'
    )

    BELL_ICON = (
        AppiumBy.XPATH,
        '//android.view.View[@content-desc="Notification Icon"]'
    )

    GUEST_WIFI = (
        AppiumBy.XPATH,
        '//android.view.View[@content-desc="Create Guest Icon"]'
    )

    STB_REMOTE = (
        AppiumBy.XPATH,
        '//android.view.View[@content-desc="Unlabelled Icon"]'
    )

    # REBOOT = (
    #     AppiumBy.XPATH,
    #     '//android.widget.ScrollView/android.view.View[2]/android.view.View[3]'
    # )



    PARENTAL_CONTROL = (
        AppiumBy.XPATH,
        '//android.widget.Button[@content-desc="Get Started"]'
    )

    SMART_DEVICES = (
        AppiumBy.XPATH,
        '//android.widget.Button[@content-desc="Learn more smart devices"]'
    )

    NETWORK = (
        AppiumBy.XPATH,
        '//android.view.View[@content-desc="Network"]'
    )

    MORE = (
        AppiumBy.XPATH,
        '//android.view.View[@content-desc="More"]'
    )

    CLOSE_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Close Button"
    )

    BACK_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Back"
    )
    STB_REMOTE_BACK = (
        AppiumBy.ACCESSIBILITY_ID,
        "Navigation back button"
    )
    REBOOT_CLOSE = (
        AppiumBy.ACCESSIBILITY_ID,
        "Close"
    )
