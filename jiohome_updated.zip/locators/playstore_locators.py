from appium.webdriver.common.appiumby import AppiumBy


class PlayStoreLocators:

    SEARCH_BAR = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textContains("Search Apps")'
    )

    SEARCH_INPUT = (
        AppiumBy.CLASS_NAME,
        'android.widget.EditText'
    )

    JIOHOME_SEARCH_RESULT = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textContains("JioHome")'
    )

    INSTALL_BUTTON = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().className("android.widget.Button").textContains("Install")'
    )

    OPEN_BUTTON = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().className("android.widget.Button").textContains("Open")'
    )

    UPDATE_BUTTON = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().className("android.widget.Button").textContains("Update")'
    )
