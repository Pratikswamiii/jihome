from appium.webdriver.common.appiumby import AppiumBy


class DeviceLocators:
    PLAY_STORE_ICON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Play Store"
    )

    SEARCH_APPS = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textContains("Search")'
    )

    JIOHOME_APP_ICON = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().text("JioHome")'
    )
