from appium.webdriver.common.appiumby import AppiumBy


class HomeLocators:

    MOBILE_INPUT = (
        AppiumBy.XPATH,
        "//android.widget.EditText"
    )

    GET_OTP_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Get OTP"
    )

    SUBMIT_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Submit"
    )

    RESEND_OTP_BUTTON = (
        AppiumBy.ACCESSIBILITY_ID,
        "Resend OTP"
    )

