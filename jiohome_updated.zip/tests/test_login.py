import allure

from pages.device_page import DevicePage
from pages.home_page import HomePage
from pages.playstore_page import PlayStorePage
from utils.logger import logger


@allure.feature("Login")
@allure.story("Valid Login")
@allure.title("Verify login with valid mobile number")
def test_login(driver):

    device_page = DevicePage(driver)
    playstore_page = PlayStorePage(driver)
    home_page = HomePage(driver)

    logger.info("Starting JioHome application discovery flow")

    device_page.go_to_home_screen()
    device_page.open_app_search()

    if device_page.is_jiohome_visible():
        logger.info("JioHome app found on device")
        device_page.open_jiohome_from_launcher()
    else:
        logger.info("JioHome app not found. Opening Play Store")
        device_page.open_play_store()
        playstore_page.search_jiohome()
        playstore_page.install_or_open_jiohome()

    home_page.login()
