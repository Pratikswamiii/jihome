
import allure

from pages.home_page import HomePage
from pages.home_navigation_page import HomeNavigationPage


@allure.feature("Homepage Navigation")
@allure.story("Homepage Tabs Validation")
@allure.title("Validate homepage navigation flow")
def test_homepage_navigation(driver):

    home_page = HomePage(driver)

    navigation_page = HomeNavigationPage(driver)

    home_page.login()

    navigation_page.validate_homepage_navigation()
