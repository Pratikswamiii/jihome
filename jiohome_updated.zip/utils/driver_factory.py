from appium import webdriver
from appium.options.android import UiAutomator2Options

from utils.config import (
    APP_PACKAGE,
    APP_ACTIVITY,
    APPIUM_SERVER
)


class DriverFactory:

    @staticmethod
    def get_driver():

        options = UiAutomator2Options()

        options.platform_name = "Android"
        options.device_name = "Android"
        options.automation_name = "UiAutomator2"

        options.app_package = "com.jio.home"
        options.app_activity = "com.jio.home.cleanarchitecture.common.screen.JioHomeLaunchActivity"

        options.no_reset = True
        options.auto_grant_permissions = True

        driver = webdriver.Remote(
            APPIUM_SERVER,
            options=options
        )

        driver.implicitly_wait(5)

        return driver