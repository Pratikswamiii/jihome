
from pages.base_page import BasePage


class JioRouterPage(BasePage):

    pass
