
from pages.base_page import BasePage


class NetworkPage(BasePage):

    pass
