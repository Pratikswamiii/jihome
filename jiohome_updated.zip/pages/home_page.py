import time
import allure

from pages.base_page import BasePage
from locators.home_locators import HomeLocators
from utils.logger import logger


class HomePage(BasePage):

    def enter_mobile_number(self, mobile_number="8104913714"):

        logger.info("Jio Home app opened successfully")

        with allure.step("Enter mobile number"):

            self.enter_text(
                HomeLocators.MOBILE_INPUT,
                mobile_number
            )

            logger.info(
                f"Mobile number entered successfully: {mobile_number}"
            )

            allure.attach(
                mobile_number,
                name="Entered Mobile Number",
                attachment_type=allure.attachment_type.TEXT
            )

    def click_get_otp(self):

        with allure.step("Click Get OTP button"):

            self.click(
                HomeLocators.GET_OTP_BUTTON
            )

            logger.info("Get OTP button clicked successfully")

            allure.attach(
                "OTP requested successfully",
                name="OTP Status",
                attachment_type=allure.attachment_type.TEXT
            )

    def wait_for_manual_otp_and_submit(self):

        with allure.step("Wait for manual OTP entry"):

            logger.info("Waiting for user to enter OTP manually")

            resend_start_time = time.time()

            while True:

                # Submit button enabled means OTP entered
                if self.is_enabled(
                        HomeLocators.SUBMIT_BUTTON
                ):

                    logger.info("OTP entered successfully")

                    allure.attach(
                        "OTP entered manually by user",
                        name="OTP Received",
                        attachment_type=allure.attachment_type.TEXT
                    )

                    self.click(
                        HomeLocators.SUBMIT_BUTTON
                    )

                    logger.info("Submit button clicked")

                    allure.attach(
                        "Submit button clicked successfully",
                        name="Submit Status",
                        attachment_type=allure.attachment_type.TEXT
                    )

                    logger.info("Login completed successfully")

                    allure.attach(
                        "User logged in successfully",
                        name="Login Success",
                        attachment_type=allure.attachment_type.TEXT
                    )

                    break

                # Resend OTP every 30 seconds
                current_time = time.time()

                if current_time - resend_start_time >= 30:

                    if self.is_visible(
                            HomeLocators.RESEND_OTP_BUTTON
                    ):

                        logger.info("Resend OTP button visible")

                        self.click(
                            HomeLocators.RESEND_OTP_BUTTON
                        )

                        logger.info("Resend OTP clicked successfully")

                        allure.attach(
                            "Resend OTP clicked",
                            name="OTP Resend",
                            attachment_type=allure.attachment_type.TEXT
                        )

                    resend_start_time = current_time

                time.sleep(2)

    def login(self, mobile_number="8104913714"):

            logger.info("Starting login flow")

            # Already logged in case
            if self.is_visible(
                    HomeLocators.GET_OTP_BUTTON,
                    timeout=5
            ):

                logger.info("Login screen detected")

                self.enter_mobile_number(mobile_number)

                self.click_get_otp()

                self.wait_for_manual_otp_and_submit()

            else:

                logger.info("User already logged in. Skipping login flow")
