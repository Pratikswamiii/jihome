
from pages.base_page import BasePage


class MorePage(BasePage):

    pass
