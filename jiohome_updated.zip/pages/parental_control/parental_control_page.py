
from pages.base_page import BasePage


class ParentalControlPage(BasePage):

    pass
