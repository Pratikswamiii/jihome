import allure
from appium.webdriver.appium_service import AppiumService

from pages.base_page import BasePage
from locators.device_locators import DeviceLocators
from utils.logger import logger


class DevicePage(BasePage):

    def go_to_home_screen(self):
        logger.info("Navigating to device home screen")
        self.driver.press_keycode(3)

    def open_app_search(self):
        if self.is_visible(DeviceLocators.SEARCH_APPS, timeout=5):
            self.click(DeviceLocators.SEARCH_APPS)

    def is_jiohome_visible(self):
        return self.is_visible(DeviceLocators.JIOHOME_APP_ICON, timeout=5)

    def open_jiohome_from_launcher(self):
        with allure.step("Open JioHome app from launcher"):
            self.click(DeviceLocators.JIOHOME_APP_ICON)
            logger.info("JioHome app launched from launcher")

    def open_play_store(self):
        with allure.step("Open Play Store"):
            self.click(DeviceLocators.PLAY_STORE_ICON)
            logger.info("Play Store launched successfully")
