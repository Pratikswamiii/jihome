
from pages.base_page import BasePage


class SmartDevicesPage(BasePage):

    pass
