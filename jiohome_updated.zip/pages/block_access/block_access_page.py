
from pages.base_page import BasePage


class BlockAccessPage(BasePage):

    pass
