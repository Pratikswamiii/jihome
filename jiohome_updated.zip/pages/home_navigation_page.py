
import time
import allure

from pages.base_page import BasePage
from locators.home_navigation_locators import HomeNavigationLocators
from utils.logger import logger


class HomeNavigationPage(BasePage):

    def open_module_and_return(
            self,
            locator,
            module_name,
            navigation_type,
            home_locator
    ):

        with allure.step(f"Open {module_name}"):

            logger.info(f"Opening {module_name}")

            self.click(locator)

            logger.info(f"{module_name} opened successfully")

            time.sleep(3)

            # Handle navigation based on screen type
            if navigation_type == "close":

                logger.info(
                    f"Using close button for {module_name}"
                )

                self.click(
                    HomeNavigationLocators.CLOSE_BUTTON
                )

            elif navigation_type == "back":

                logger.info(
                    f"Using back button for {module_name}"
                )

                self.click(
                    HomeNavigationLocators.BACK_BUTTON
                )

            logger.info(
                f"Returned successfully from {module_name}"
            )

            # Wait homepage restore
            start_time = time.time()

            while time.time() - start_time < 15:

                if self.is_visible(home_locator, timeout=2):
                    logger.info(
                        f"Homepage restored after {module_name}"
                    )

                    return

                time.sleep(1)

            raise Exception(
                f"Homepage not restored after {module_name}"
            )

    def validate_homepage_navigation(self):

        # Plus Icon -> Close Button
        self.open_module_and_return(
            HomeNavigationLocators.PLUS_ICON,
            "Plus Icon",
            "close",
            HomeNavigationLocators.PLUS_ICON
        )

        # Bell Icon -> Back Button
        self.open_module_and_return(
            HomeNavigationLocators.BELL_ICON,
            "Bell Icon",
            "back",
            HomeNavigationLocators.PLUS_ICON
        )

        # Jio Router -> Close Button
        self.open_module_and_return(
            HomeNavigationLocators.JIO_ROUTER,
            "Jio Router",
            "close",
            HomeNavigationLocators.PLUS_ICON
        )

        # Guest Wifi -> Back Button
        self.open_module_and_return(
            HomeNavigationLocators.GUEST_WIFI,
            "Guest Wifi",
            "back",
            HomeNavigationLocators.PLUS_ICON
        )

        # STB Remote -> Back Button
        # self.open_module_and_return(
        #     HomeNavigationLocators.STB_REMOTE,
        #     "STB Remote",
        #     "back",
        #     HomeNavigationLocators.PLUS_ICON
        # )
        # STB Remote Special Navigation
        with allure.step("Open STB Remote"):
            logger.info("Opening STB Remote")

            self.click(
                HomeNavigationLocators.STB_REMOTE
            )

            logger.info("STB Remote opened successfully")

            time.sleep(3)

            self.click(
                HomeNavigationLocators.STB_REMOTE_BACK
            )

            logger.info(
                "Returned from STB Remote successfully"
            )

            time.sleep(2)

        # Reboot -> Close Button
        # Reboot Special Navigation
        # with allure.step("Open Reboot"):
        #     logger.info("Opening Reboot")
        #
        #     self.click(
        #         HomeNavigationLocators.REBOOT
        #     )
        #
        #     logger.info("Reboot opened successfully")
        #
        #     time.sleep(3)
        #
        #     self.click(
        #         HomeNavigationLocators.REBOOT_CLOSE
        #     )
        #
        #     logger.info(
        #         "Returned from Reboot successfully"
        #     )
        #
        #     time.sleep(2)

        # Block Access -> Back Button
        # self.open_module_and_return(
        #     HomeNavigationLocators.BLOCK_ACCESS,
        #     "Block Access",
        #     "back",
        #     HomeNavigationLocators.PLUS_ICON
        # )

        # Parental Control -> Back Button
        self.open_module_and_return(
            HomeNavigationLocators.PARENTAL_CONTROL,
            "Parental Control",
            "back",
            HomeNavigationLocators.PLUS_ICON
        )
        # Scroll homepage for lower modules
        self.scroll_down()

        # Smart Devices -> Back Button
        self.open_module_and_return(
            HomeNavigationLocators.SMART_DEVICES,
            "Smart Devices",
            "back",
            HomeNavigationLocators.PLUS_ICON
        )

        # Network -> Back Button
        # self.open_module_and_return(
        #     HomeNavigationLocators.NETWORK,
        #     "Network",
        #     "back",
        #     HomeNavigationLocators.PLUS_ICON
        # )
        # Network Special Navigation
        with allure.step("Open Network"):
            logger.info("Opening Network")

            self.click(
                HomeNavigationLocators.NETWORK
            )

            logger.info("Network opened successfully")

            time.sleep(3)

            logger.info(
                "Using Android back for Network"
            )

            self.driver.back()

            time.sleep(2)

            logger.info(
                "Returned from Network successfully"
            )

        # More -> Back Button
        self.open_module_and_return(
            HomeNavigationLocators.MORE,
            "More",
            "back",
            HomeNavigationLocators.PLUS_ICON
        )
