
from pages.base_page import BasePage


class StbRemotePage(BasePage):

    pass
