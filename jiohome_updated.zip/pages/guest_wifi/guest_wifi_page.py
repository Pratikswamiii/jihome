
from pages.base_page import BasePage


class GuestWifiPage(BasePage):

    pass
